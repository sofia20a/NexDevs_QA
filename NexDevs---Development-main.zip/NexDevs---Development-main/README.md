
# NexDevs

This repository contains the source code and resources for the NexDevs system. The project is currently in the development phase and is managed by a collaborative team. The main objective is to develop a system that meets the specifications and requirements defined in the course.






## Authors

- [@benjaminpaniagua](https://github.com/benjaminpaniagua)
- [@dianaartavia](https://github.com/dianaartavia)
- [@freddy74](https://github.com/freddy74)
- [@sofia20a](https://github.com/sofia20a)
- [@LuisCarlosSolis](https://github.com/LuisCarlosSolis)



